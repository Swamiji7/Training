package com.lti.training.servlet;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login.lti")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// reading the form request data
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		DatabaseUserManager um=new DatabaseUserManager();
		boolean isValid=um.isValidUser(username, password);
		
		/*if (username.equals(username) && password.equals(password)) {
			*/
		if(isValid==true) {
			String rememberme = request.getParameter("rememberme");
			if (rememberme != null && rememberme.equals("yes")) {

				String encodedusername = Base64.getEncoder().encodeToString(
			            username.getBytes("utf-8"));
				String encodedpassword = Base64.getEncoder().encodeToString(
			            password.getBytes("utf-8"));
				Cookie c1=new Cookie("username",encodedusername);
				Cookie c2 =new Cookie("password", encodedpassword);
				c1.setMaxAge(60*60);  //1 hr storage, generally we store the age in seconds
				c2.setMaxAge(60*60);
				response.addCookie(c1);
				response.addCookie(c2);
			}
				response.sendRedirect("welcome.html");
			
		} else {

			response.sendRedirect("login.html");
		}
	}

}
