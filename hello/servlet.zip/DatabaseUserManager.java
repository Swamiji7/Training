package com.lti.training.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUserManager {

	public boolean isValidUser(String username, String password) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			// loading the JDBC driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "hr", "hr");
			
			String sql = "select username,password from tb_user where act=1";
			stmt = conn.prepareStatement(sql);
			
			ResultSet rs = stmt.executeQuery();
			System.out.println("System Connected Successfully");
			while (rs.next()) {
				if (rs.getString(1).equals(username)) 
					if (rs.getString(2).equals(password))
						return true;
			}
		} catch (SQLException e) {
			System.out.println("SQL Exception");
			
		} catch (ClassNotFoundException e) {

			System.out.println("JDBC driver not found");
			}
		return false;

	}
}
